int main()
{
  char c = 1000;
  return c;
}
