This package provides a minor mode to frobnicate and/or bifurcate
any flanges you desire. To activate it, type "C-M-r M-3 butterfly"
and all your dreams will come true.
